/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2014 Intel Corporation. All rights reserved.
 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */
// <ORIGINAL-AUTHOR>: Greg Lueck
// <COMPONENT>: sync
// <FILE-TYPE>: component private header

#ifndef SYNC_BACKOFF_OR_YIELD_HPP
#define SYNC_BACKOFF_OR_YIELD_HPP

#include "atomic.hpp"


namespace SYNC {


/*!
 * This utility can be used to implement the delay in the body of a spin-wait
 * loop.  Initial iterations of the delay use an exponential backoff that
 * actively spins on the CPU.  However, after a limit is reached, each delay
 * iteration makes an O/S call to yield the processor.
 *
 * @tparam OS               Type which provides O/S primitives.  See
 *                           \ref SYNC_OS.  The \a OS type must define the
 *                           Yield() method.
 * @tparam BACKOFF_LIMIT    The iteration limit, after which each delay
 *                           makes a call to Yield().  Since each iteration is
 *                           exponential, the total delay before doing a
 *                           Yield() is proportional to 2^BACKOFF_LIMIT.
 */
template<typename OS, unsigned BACKOFF_LIMIT> class /*<UTILITY>*/ BACKOFF_OR_YIELD
{
public:
    BACKOFF_OR_YIELD() : _backoff(0) {}

    void Delay()
    {
        if (_backoff.GetIterationCount() < BACKOFF_LIMIT)
            _backoff.Delay();
        else
            OS::Yield();
    }

private:
    ATOMIC::EXPONENTIAL_BACKOFF<> _backoff;
};

} // namespace
#endif // file guard
